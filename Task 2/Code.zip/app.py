import csv
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import json
from flask import Flask,jsonify,render_template,request
from flask_cors import CORS
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
from sklearn import manifold
from collections import defaultdict

app = Flask(__name__)
CORS(app)

df = pd.read_csv('static/data/pokemon.csv',usecols=['attack','defense','hp','sp_attack','sp_defense','speed','base_total','height_m','weight_kg','capture_rate'])
df.replace('', np.nan, inplace=True)
df.replace('Not Found', np.nan, inplace=True)
df.dropna( inplace=True)

scalar = StandardScaler()
mixmaxscalar = MinMaxScaler()
columns_ = df.select_dtypes(include=['int64', 'float64']).columns
columns_PC = ["PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8","PC9"]
df = df[columns_]

scaled_df = scalar.fit_transform(df[columns_])
scaled_df = pd.DataFrame(scaled_df, columns=columns_)
scaled_df = pd.DataFrame(mixmaxscalar.fit_transform(scaled_df), columns=columns_)

pca = PCA(n_components=9)
pca_s = pca.fit_transform(scaled_df)

pca_variance_ratio = pca.explained_variance_ratio_
pca_variance_cumsum = pca_variance_ratio.cumsum()

topComponents = 0

@app.route('/')
def index():
    global topComponents
    topComponents = 0
    return render_template('index.html')

@app.route('/screeplot', methods=['GET', 'POST'])
def screeplot():
    global topComponents
    if request.method == 'POST':
        topComponents = request.get_json()
    return jsonify(pca_variance_ratio.tolist(),pca_variance_cumsum.tolist())

eiganvectors = pd.DataFrame(data = pca_s, columns=columns_PC)
loadings = pd.DataFrame(pca.components_.T, columns=columns_PC, index=columns_)

kmeans_res_el = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, init='k-means++', random_state=42)
    kmeans.fit(scaled_df)
    kmeans_res_el.append(kmeans.inertia_)

kmeans = KMeans(n_clusters= 3)
kmeans_res = kmeans.fit_predict(scaled_df)

@app.route('/biplot')
def biplot():
    data = {
        'load': loadings[['PC1','PC2']].to_dict(),
        'eigen': eiganvectors[['PC1','PC2']].to_dict(),
        'kmeans_color': kmeans_res.tolist()
    }
    return jsonify(json.dumps(data))

@app.route('/elbowplot')
def elbowplot():
    return jsonify(kmeans_res_el)

columns_list = columns_.tolist()

@app.route('/scatterplot')
def scatterplot():
    global topComponents
    if topComponents!=0:
        top_value = topComponents['key']
        top_value = int(top_value) + 1
    else:
        top_value = -1
    if top_value>0:
        sum = defaultdict(list)
        for i in range(0,top_value):
            if i==0:
                for j in range(0,9):
                    sum[columns_list[j]].append(loadings[columns_PC[i]][columns_list[j]]**2)
            else:
                for j in range(0,9):
                    sum[columns_list[j]][0] += loadings[columns_PC[i]][columns_list[j]]**2
        sorted_sum = sorted(sum.items(), key=lambda x: x[1], reverse=True)
        features = []
        for i in range(0,4):
            features.append(sorted_sum[i][0])
        pca_comp = loadings[columns_PC[:top_value]].T[features].T
    else:
        sum = defaultdict(list)
        for i in range(0,9):
            if i==0:
                for j in range(0,9):
                    sum[columns_list[j]].append(loadings[columns_PC[i]][columns_list[j]]**2)
            else:
                for j in range(0,9):
                    sum[columns_list[j]][0] += loadings[columns_PC[i]][columns_list[j]]**2
        sorted_sum = sorted(sum.items(), key=lambda x: x[1], reverse=True)
        features = []
        for i in range(0,4):
            features.append(sorted_sum[i][0])
        pca_comp = loadings.T[features].T
   
    pca_comp['Squared Sum PCA Loadings']= sorted_sum[:4]
    pca_comp['Squared Sum PCA Loadings'] = pca_comp['Squared Sum PCA Loadings'].apply(lambda x: x[1][0])

    df['kmeans_color'] = kmeans_res.tolist()
    features_ = features + ['kmeans_color']
    df_scat = df[features_].T
    rangeDom = {}
    features_dict = {v: k for v, k in enumerate(features)}
    for i in features:
        rangeDom[i] = {"mn":min(df[i]),"mx":max(df[i])}
    obj_ = {
        'data':list(df_scat.to_dict().values()),
        'table_data':pca_comp.to_dict(),
        'table_data_sup':pca_comp.T.to_dict(),
        'domainRange':rangeDom,
        'features':features_dict
    }
    return jsonify(json.dumps(obj_))

if __name__ == '__main__':
    app.run(debug=True)
